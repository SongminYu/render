from Melodie import DataLoader


class _ALIAS_DataframeLoader(DataLoader):
    def register_scenario_dataframe(self):
        pass

    def register_static_dataframes(self):
        pass

    def generate_dataframe(self):
        pass
