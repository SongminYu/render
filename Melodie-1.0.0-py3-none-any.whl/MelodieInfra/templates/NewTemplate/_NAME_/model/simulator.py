from Melodie import Simulator


class _ALIAS_Simulator(Simulator):
    pass
