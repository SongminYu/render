import os

from config import config
from MelodieStudio import studio_main

studio_main(config)
